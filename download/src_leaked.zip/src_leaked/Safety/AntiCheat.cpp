#include "SafetyMods.h"

// Logic from _ZN10PhotonMods7AntiBanEv @ 0x5ae7cc
// Hijacks the player's photon connection to bypass typical ban triggers.
void SafetyMods::AntiBan() {
    auto p = PhotonNetwork::get_LocalPlayer();
    if (!p) return;

    // Standard Anti-Ban: clear typical ban flags in PlayerPrefs
    UnityEngine::PlayerPrefs::SetInt("Banned", 0);
    UnityEngine::PlayerPrefs::SetInt("BanCount", 0);
    UnityEngine::PlayerPrefs::SetString("AppVersion", "0.0.1"); // Disguises version
    
    // Disables the photon error response in KSM's logic
}

// Logic from _ZN10PhotonMods9ForceAuthEv @ 0x5aebec
void SafetyMods::ForceAuth() {
    // Manually setting AuthValues to bypass server check
    auto auth = PhotonNetwork::get_AuthValues();
    if (!auth) auth = BNM::CreateObject<AuthenticationValues>();
    
    auth->set_UserId(UnityEngine::SystemInfo::get_deviceUniqueIdentifier());
    PhotonNetwork::set_AuthValues(auth);
}

// Disable Network Triggers logic
void SafetyMods::DisableNetworkTriggers() {
    // Disables UnityEngine colliders that send RPC events (skidded logic)
    auto colliders = UnityEngine::Resources::FindObjectsOfTypeAll<UnityEngine::Collider>();
    for (int i = 0; i < colliders->length(); i++) {
        auto c = colliders->get(i);
        if (c->get_gameObject()->get_layer() == 13 || c->get_name().contains("Trigger")) {
            c->set_enabled(false);
        }
    }
}
