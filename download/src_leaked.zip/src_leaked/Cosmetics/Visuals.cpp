#include "CosmeticMods.h"

// Logic from _ZN12VisualMods9UnlockAllEv @ similar
// Iterates through allCosmetics in CosmeticsController.
void CosmeticMods::UnlockAll() {
    auto controller = CosmeticsController::get_Instance();
    if (!controller) return;

    auto allCosmetics = controller->allCosmetics();
    for (int i = 0; i < allCosmetics->length(); i++) {
        auto item = allCosmetics->get(i);
        if (item) {
             // Reconstructed PlayFab Item State access
             item->set_Unlocked(true);
             item->set_Balance(999999);
        }
    }
}

// Logic from _ZN12VisualMods7RGBColorEv @ similar
// Uses BNM::Structures::Unity::Color with hsvToRgb.
static float hue = 0.0f;
void CosmeticMods::RGBColor() {
    hue += UnityEngine::Time::get_deltaTime() * 0.1f;
    if (hue > 1.0f) hue = 0.0f;

    auto color = UnityEngine::Color::HSVToRGB(hue, 1.0f, 1.0f);
    auto localRig = GorillaTagger::get_Instance()->offlineVRRig();
    if (localRig) {
        localRig->UpdateColor(color.r, color.g, color.b);
    }
}

// Strobe Color logic
void CosmeticMods::StrobeColor() {
    static int frame = 0;
    frame++;

    BNM::Structures::Unity::Color color;
    if (frame % 2 == 0) color = BNM::Structures::Unity::Color(1.0f, 1.0f, 1.0f, 1.0f);
    else color = BNM::Structures::Unity::Color(0.0f, 0.0f, 0.0f, 1.0f);

    auto localRig = GorillaTagger::get_Instance()->offlineVRRig();
    if (localRig) localRig->UpdateColor(color.r, color.g, color.b);
}

// PlayFab Patcher logic
void CosmeticMods::PlayfabPatcher() {
    // Hijacks PlayFab.ClientModels to simulate successful item purchase
    static void* PlayFabAuth = BNM::FindClass("PlayFab.PlayFabClientAPI");
    // This is typically a hook into ResultCallback, but logic is simplified here:
    // Simply sets local flags for successful item receipt.
    CosmeticMods::UnlockAll();
}
