#include "VisualMods.h"

// Logic from _ZN10VisualMods9TargetGunEv @ 0x5af154
// Draws a line to the aimed target using LineRenderer.
void VisualMods::TargetGun() {
    static LineRenderer* lr = nullptr;
    if (Unity::Input::GetTrigger(Unity::Hand::Right)) {
        if (!lr) {
            lr = BNM::CreateObject<LineRenderer>();
            lr->set_startWidth(0.01f);
            lr->set_endWidth(0.01f);
            lr->set_useWorldSpace(true);
        }
        
        RaycastHit hit;
        auto hand = GorillaTagger::get_Instance()->offlineVRRig()->rightHandTransform();
        if (Physics::Raycast(hand->get_position(), hand->get_forward(), &hit)) {
            lr->SetPosition(0, hand->get_position());
            lr->SetPosition(1, hit.point);
        }
    } else if (lr) {
        GameObject::Destroy(lr);
        lr = nullptr;
    }
}

// Logic from _ZN10VisualMods10NoHandTapsEv @ 0x5aef2c
// Sets tap volume multiplier to 0.
void VisualMods::NoHandTaps() {
    auto tagger = GorillaTagger::get_Instance();
    if (tagger) {
        tagger->set_handTapVolume(0.0f);
    }
}

// Restoration logic
void VisualMods::LoudHandTaps() {
    auto tagger = GorillaTagger::get_Instance();
    if (tagger) {
        tagger->set_handTapVolume(100.0f);
    }
}

// Logic from _ZN10VisualMods6BugGunEv @ 0x5aefb0
// Forces the "Bug" holdable into a specific target's hands.
void VisualMods::BugGun() {
    if (Unity::Input::GetTrigger(Unity::Hand::Right)) {
        RaycastHit hit;
        auto hand = GorillaTagger::get_Instance()->offlineVRRig()->rightHandTransform();
        if (Physics::Raycast(hand->get_position(), hand->get_forward(), &hit)) {
            auto rig = hit.collider()->GetComponentInParent<VRRig>();
            if (rig) {
                // Skidded Bug Logic: Finds the Bug object and calls Grab via RPC
                auto bug = GameObject::Find("Floating Bug");
                if (bug) {
                    PhotonNetwork::RPC("GrabBug", rig->get_owner(), nullptr);
                }
            }
        }
    }
}

// Logic for Disconnect/Reconnect Rooms
void PhotonMods::Reconnect() {
    auto settings = PhotonNetwork::get_PhotonServerSettings();
    PhotonNetwork::ReconnectAndRejoin();
}
