#include "MovementMods.h"

// Scale Player: Modifies the transform of the LocalPlayer.
// Reconstructed from _ZN12MovementMods8FixScaleEv @ 0x5ae4c0

// Reset Player to original scale.
void MovementMods::FixScale() {
    auto player = GorillaLocomotion::Player::get_Instance();
    if (player) {
         // Standard scale: 1.0f on all axes
         player->get_transform()->set_localScale(BNM::Structures::Unity::Vector3(1.0f, 1.0f, 1.0f));
    }
}

// Scale Up/Down Logic.
void MovementMods::ScalePlayer(float scaleFactor) {
    auto tagger = GorillaTagger::get_Instance();
    if (!tagger) return;

    auto rig = tagger->offlineVRRig();
    if (rig) {
        // Apply to the root transform of the player logic
        auto player = GorillaLocomotion::Player::get_Instance();
        player->get_transform()->set_localScale(BNM::Structures::Unity::Vector3(scaleFactor, scaleFactor, scaleFactor));
    }
}
