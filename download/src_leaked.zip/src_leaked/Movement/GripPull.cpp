#include "MovementMods.h"

// Grip Pull: Adds a velocity vector towards the right hand's forward direction.
// Reconstructed from _ZN12MovementMods9TpPullModEv @ 0x5ae63c

void MovementMods::TpPullMod() {
    auto rig = GorillaTagger::get_Instance()->offlineVRRig();
    if (!rig) return;

    // Detect Grip press on right controller
    if (Unity::Input::GetGrip(Unity::Hand::Right)) {
        auto player = GorillaLocomotion::Player::get_Instance();
        auto hand = player->rightHandTransform();
        auto rb = player->playerRigidBody();
        // Exact multiplier and force mode used in KSM
        Vector3 force = hand->get_forward() * 45.0f;
        rb->AddForce(force, ForceMode::Acceleration);
    }
}
