#include "MovementMods.h"

// Reconstructed from _ZN12MovementMods4AFlyEv @ 0x5adf88
// Uses A-button on right controller.
void MovementMods::AFly() {
    // 0x5adf88 logic
    if (Unity::Input::GetButton(Unity::Button::A)) {
        auto player = GorillaLocomotion::Player::get_Instance();
        if (player) {
            auto head = player->headCollider()->get_transform();
            auto rb = player->playerRigidBody();
            // Force factor found in binary
            rb->set_velocity(head->get_forward() * 10.0f);
        }
    }
}

// Reconstructed from _ZN12MovementMods4TFlyEv @ 0x5ae07c
// Uses Right hand trigger.
void MovementMods::TFly() {
    // 0x5ae07c logic
    if (Unity::Input::GetTrigger(Unity::Hand::Right)) {
        auto player = GorillaLocomotion::Player::get_Instance();
        if (player) {
            auto hand = player->rightHandTransform();
            auto rb = player->playerRigidBody();
            rb->set_velocity(hand->get_forward() * 15.0f);
        }
    }
}

// Reconstructed from _ZN12MovementMods7barkflyEv @ 0x5ae430
// Skidded from 'Bark' menu logic.
void MovementMods::barkfly() {
    // 0x5ae430 logic
    auto player = GorillaLocomotion::Player::get_Instance();
    if (!player) return;

    if (Unity::Input::GetGrip(Unity::Hand::Left)) {
        auto rb = player->playerRigidBody();
        auto leftHand = player->leftHandTransform();
        // Fly forward towards where left hand is pointing
        rb->set_velocity(leftHand->get_forward() * 12.0f);
        rb->set_useGravity(false);
    } else {
        player->playerRigidBody()->set_useGravity(true);
    }
}
