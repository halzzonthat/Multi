#include "MovementMods.h"

// Reconstructed from _ZN12MovementMods8LongArmsEv @ 0x5ae494
// This logic targets the VRRig hand offsets directly via BNM.

void MovementMods::LongArms() {
    auto tagger = GorillaTagger::get_Instance();
    if (!tagger) return;

    auto offlineRig = tagger->offlineVRRig();
    if (offlineRig) {
        // Standard "Long Arms" offset used in Kat's menu
        auto offset = BNM::Structures::Unity::Vector3(0.0f, 0.45f, 0.0f); 
        
        auto leftHand = offlineRig->leftHandTransform();
        auto rightHand = offlineRig->rightHandTransform();
        
        if (leftHand) leftHand->set_localPosition(offset);
        if (rightHand) rightHand->set_localPosition(offset);
    }
}

// Restoration logic
void MovementMods::FixArms() {
    auto tagger = GorillaTagger::get_Instance();
    if (!tagger) return;

    auto offlineRig = tagger->offlineVRRig();
    if (offlineRig) {
        auto zero = BNM::Structures::Unity::Vector3(0.0f, 0.0f, 0.0f);
        offlineRig->leftHandTransform()->set_localPosition(zero);
        offlineRig->rightHandTransform()->set_localPosition(zero);
    }
}
