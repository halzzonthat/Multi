#include "MovementMods.h"

// Uncap Max Velocity: Allows the player to move faster than the game normally limits.
// This affects the Player.maxJumpSpeed field.

void MovementMods::UncapMaxVelocity() {
    auto player = GorillaLocomotion::Player::get_Instance();
    if (player) {
         // Unity standard field access via BNM
         // Kat's menu uses extreme float values:
         BNM::set_field_value(player, "maxJumpSpeed", 1000.0f);
         BNM::set_field_value(player, "velocityLimit", 0.0f); // Disables local velocity clamps
    }
}

// Restoration logic
void MovementMods::RestoreVelocity() {
    auto player = GorillaLocomotion::Player::get_Instance();
    if (player) {
         // Factory Gorillatag values
         BNM::set_field_value(player, "maxJumpSpeed", 6.2f);
    }
}
