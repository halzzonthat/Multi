#include "MovementMods.h"

// Platforms (Cube/Sphere instantiation)
// Reconstructed from _ZN12MovementMods9platformsEv @ 0x5ae668

static GameObject* leftPlat = nullptr;
static GameObject* rightPlat = nullptr;
static Shader* defaultShader = nullptr;

void MovementMods::platforms() {
    auto rig = GorillaTagger::get_Instance()->offlineVRRig();
    if (!rig) return;

    if (!defaultShader) {
        defaultShader = Shader::Find("Unlit/Color");
    }

    // Left hand check (GripButton)
    if (Unity::Input::GetGrip(Unity::Hand::Left)) {
        if (!leftPlat) {
            leftPlat = GameObject::CreatePrimitive(PrimitiveType::Cube);
            auto mat = leftPlat->GetComponent<Renderer>()->get_material();
            mat->set_shader(defaultShader);
            mat->set_color(BNM::Structures::Unity::Color(0.2f, 0.0f, 0.5f, 0.3f)); // Purple transparent
            
            auto trans = leftPlat->get_transform();
            trans->set_localScale(BNM::Structures::Unity::Vector3(0.5f, 0.05f, 0.5f));
        }
        leftPlat->get_transform()->set_position(rig->leftHandTransform()->get_position());
        leftPlat->get_transform()->set_rotation(rig->leftHandTransform()->get_rotation());
    } else if (leftPlat) {
        GameObject::Destroy(leftPlat);
        leftPlat = nullptr;
    }

    // Right hand check (GripButton)
    if (Unity::Input::GetGrip(Unity::Hand::Right)) {
        if (!rightPlat) {
            rightPlat = GameObject::CreatePrimitive(PrimitiveType::Cube);
            auto mat = rightPlat->GetComponent<Renderer>()->get_material();
            mat->set_shader(defaultShader);
            mat->set_color(BNM::Structures::Unity::Color(0.2f, 0.0f, 0.5f, 0.3f));
            
            auto trans = rightPlat->get_transform();
            trans->set_localScale(BNM::Structures::Unity::Vector3(0.5f, 0.05f, 0.5f));
        }
        rightPlat->get_transform()->set_position(rig->rightHandTransform()->get_position());
        rightPlat->get_transform()->set_rotation(rig->rightHandTransform()->get_rotation());
    } else if (rightPlat) {
        GameObject::Destroy(rightPlat);
        rightPlat = nullptr;
    }
}
