#include "MovementMods.h"

// Reconstructed from _ZN12MovementMods9NoGravityEv @ 0x5ae524
// Pure zero gravity by hijacking Rigidbody.set_useGravity

void MovementMods::NoGravity() {
    auto player = GorillaLocomotion::Player::get_Instance();
    if (!player) return;

    auto rb = player->playerRigidBody();
    rb->set_useGravity(false);
}

// Low Gravity variant
// Sets Unity's global gravity to a float specified in the BNM call.
void MovementMods::LowGravity() {
    UnityEngine::Physics::set_gravity(BNM::Structures::Unity::Vector3(0.0f, -0.5f, 0.0f));
    auto player = GorillaLocomotion::Player::get_Instance();
    if (player) {
         player->playerRigidBody()->set_useGravity(true);
    }
}

// Fixed/Restore Gravity
void MovementMods::FixGravity() {
    // Reset global Physics gravity (Standard is -9.81)
    UnityEngine::Physics::set_gravity(BNM::Structures::Unity::Vector3(0.0f, -9.81f, 0.0f));
    
    auto player = GorillaLocomotion::Player::get_Instance();
    if (player) {
        player->playerRigidBody()->set_useGravity(true);
    }
}
