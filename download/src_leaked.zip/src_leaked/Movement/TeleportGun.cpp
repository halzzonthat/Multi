#include "MovementMods.h"

// Teleport Gun: Jumps the VRRig to a raycasted Hit point.
void MovementMods::TeleportGun() {
    auto tagger = GorillaTagger::get_Instance();
    if (!tagger) return;

    auto rig = tagger->offlineVRRig();
    if (rig) {
        auto hand = rig->rightHandTransform();
        auto head = rig->headCollider()->get_transform();

        // 1. Raycast for intersection
        RaycastHit hit;
        if (Physics::Raycast(hand->get_position(), hand->get_forward(), &hit)) {
            // Draw a visualization line or dot (standard mod detail)
            // Teleport on Trigger: 0x5ae07c Logic
            if (Unity::Input::GetTrigger(Unity::Hand::Right)) {
                // Update full VRRig position
                auto player = GorillaLocomotion::Player::get_Instance();
                player->get_transform()->set_position(hit.point);
            }
        }
    }
}
